﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Web;
using System.Web.Mvc;
using System.Xml.Serialization;
using mvcAddendas.Models;
using mvcAddendas.wsCerFac;
using Newtonsoft.Json;

namespace mvcAddendas.Controllers
{
    public class AddendasController : Controller
    {
        // GET: Addendas
        public ActionResult Index()
        {
            try
            {
              
                                 api();
            }
            catch (Exception ex)
            {

               // throw;
            }
            Cer_AddendasEntities obEnt = new Cer_AddendasEntities();
            List<Addendas> lst = new List<Addendas>();
            lst = obEnt.Addendas.ToList();
            return View(lst);
        }


        //Modificar

        [HttpGet]
        public ActionResult Edit(System.Guid id)
        {
            Cer_AddendasEntities obEnt = new Cer_AddendasEntities();

            var data = obEnt.Addendas.Where(x => x.IdAddenda == id).FirstOrDefault();
            return View(data);
        }
        [HttpPost]
        public ActionResult Edit(Addendas Model)
        {
            Cer_AddendasEntities obEnt = new Cer_AddendasEntities();

            var data = obEnt.Addendas.Where(x => x.IdAddenda == Model.IdAddenda).FirstOrDefault();
            if (data != null)
            {
                data.IdAddenda = Model.IdAddenda;
                data.NombreAddenda = Model.NombreAddenda;
                data.XML = Model.XML;
                data.FechaModificacion = Model.FechaModificacion;
                data.Usuario = Model.Usuario;
                data.Estado = Model.Estado;
                obEnt.SaveChanges();
            }

            return RedirectToAction("index");
        }


        //Agregar
        [HttpGet]
        public ActionResult Create()
        {
            return View();
        }

        [HttpPost]
        public ActionResult Create(Addendas model)
        {
            Cer_AddendasEntities obEnt = new Cer_AddendasEntities();
            Guid idAddenda = Guid.NewGuid();
            model.IdAddenda = idAddenda;
            obEnt.Addendas.Add(model);
            obEnt.SaveChanges();
            ViewBag.Message = "Informacion guardada!";
            return View();
        }

        

        //Borrado logico
        [HttpGet]
        public ActionResult Delete(System.Guid id)
        {
            Cer_AddendasEntities obEnt = new Cer_AddendasEntities();

            var data = obEnt.Addendas.Where(x => x.IdAddenda == id).FirstOrDefault();
            if (data != null)
            {
               // data.IdAddenda = Model.IdAddenda;
                data.Estado = false;
                obEnt.SaveChanges();
            }

            ViewBag.Messsage = "Información borrada!";
            return RedirectToAction("index");
        
        }
        
        public void api()
        {

           
            CApi obApi = new CApi();
            obApi.cfdi64 = "Cjw/eG1sIHZlcnNpb249IjEuMCIgZW5jb2Rpbmc9IlVURi04Ij8+Cjxub3RlPgogIDx0bz5Ub3ZlPC90bz4KICA8ZnJvbT5KYW5pPC9mcm9tPgogIDxoZWFkaW5nPlJlbWluZGVyPC9oZWFkaW5nPgogIDxib2R5PkRvbid0IGZvcmdldCBtZSB0aGlzIHdlZWtlbmQhPC9ib2R5Pgo8L25vdGU+IA==";
            obApi.cfdiState = "EMIT";
            obApi.isFree = "false";
            obApi.logo64 = "";
            obApi.informacionAdicional = null;
            obApi.infoNofiscal = "";
            string str = JsonConvert.SerializeObject(obApi);
            wsCerFac.IWsFact ws = new wsCerFac.WsFactClient();
            WsFactClient wsc = new WsFactClient();
            
            MessageRequest msg = new MessageRequest();

            msg.xmlBase64 = str;
            wsc.ProcessDocument(msg);

      
             

        }

       

    }
}