﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace mvcAddendas.Models
{
    public class CApi
    {
        public string cfdi64 { get; set; }
        public string cfdiState { get; set; }
        public string isFree { get; set; }
        public string logo64 { get; set; }
        public string informacionAdicional { get; set; }
        public string infoNofiscal { get; set; }


    }
}